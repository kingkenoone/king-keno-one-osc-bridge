# King Keno One OSC Bridge

A bidirectional OSC-to-MIDI VST3 instrument for Windows. Any device or application that supports OSC over UDP can communicate with the bridge.

## Getting started

1. Load the bridge as a VST3 instrument in your DAW.
2. Under **Receive**, enter the local IPv4 address and UDP port to listen on. The address 0.0.0.0 listens on all local interfaces. Configure your OSC sender to use this computer's actual network IP and the same port.
3. Under **Send**, enter the destination device's IPv4 address and OSC receive port. The address 127.0.0.1 sends feedback to the same computer.
4. Add or edit mappings, then choose **Start Bridge**. Choose **Stop Bridge** to edit settings or release the port.

## OSC and MIDI mappings

Each mapping specifies an incoming OSC address, an outgoing feedback address, MIDI type, channel, number and value. Incoming OSC messages with no argument or a positive integer or float trigger the mapping. Zero is ignored. A CC mapping sends the configured CC value. A Note mapping sends a note-on followed by note-off after 100 ms. Matching incoming MIDI CC or note events are sent to the configured outgoing OSC address as an integer.

Use the link in the lower-right corner to open King Keno One Easy OSC on Google Play. Availability depends on the app's release and test status.

The bridge starts stopped when a project is reopened. Settings and mappings are saved with the project. Network communication uses IPv4 and UDP. OSC delivery has no acknowledgement.

## Studio One and REAPER

Route the bridge's MIDI output to the input of a second instrument track, enable monitoring and select the MIDI channel matching the mapping. Choose the receiving instrument as that track's output. In Studio One, verify that the bridge is selected in the track's input field.

The user confirmed MIDI routing works in Studio One. DAW transport control through the bridge's MIDI output still requires host-specific setup and testing. REAPER also has a separate native OSC control path.
